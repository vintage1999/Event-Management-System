package com.cts.movie.util;

import java.nio.file.Path;
import java.nio.file.Paths;

public final class FileUtil {

  private FileUtil() {
    // restrict instantiation
  }

  public static final String folderPath =  "src/main/resources/static/images/";
  public static final Path filePath = Paths.get(folderPath);

}
