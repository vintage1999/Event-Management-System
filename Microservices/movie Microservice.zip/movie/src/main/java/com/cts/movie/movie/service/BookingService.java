package com.cts.movie.movie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.movie.movie.model.BookingModel;
import com.cts.movie.movie.repo.BookingRepository;

@Service
public class BookingService {
	
	@Autowired
	private BookingRepository bookingRepository;
	
	public List<BookingModel> getUserEvents(int userid) {
		
		List<BookingModel> model = this.bookingRepository.findEventsByUser(userid);
		
		return model;
		
	}
	
}
