package com.cts.movie.movie.model;

import java.io.Serializable;
import java.util.Objects;

public class BookerIdModel implements Serializable{
	/**
	 * 
	 */
	private int userid;
	private int movieid;
	
	public BookerIdModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookerIdModel(int userid, int movieid) {
		super();
		this.userid = userid;
		this.movieid = movieid;
	}
	@Override
	public int hashCode() {
		return Objects.hash(movieid, userid);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookerIdModel other = (BookerIdModel) obj;
		return movieid == other.movieid && userid == other.userid;
	}
	
}
