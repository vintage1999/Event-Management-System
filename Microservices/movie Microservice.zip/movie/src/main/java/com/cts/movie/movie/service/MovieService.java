package com.cts.movie.movie.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.movie.movie.model.MovieModel;
import com.cts.movie.movie.repo.MovieRepository;

@Service
public class MovieService {
	
	@Autowired
	private MovieRepository movieRepository;
	
	//get movie by id
	public MovieModel getMovie(int movieid) {
		Optional<MovieModel> model = this.movieRepository.findById(movieid);
		return model.get();
	}
	
	//get all movies
	public List<MovieModel> getAllMovies(){
		List<MovieModel> modellist = this.movieRepository.findAll();
		return modellist;
	}
	
	//get user movies
		public List<MovieModel> getUserMovies(int id){
			List<MovieModel> modellist = this.movieRepository.findByUserMovieId(id);
			return modellist;
		}
	
	//get movies by genre
	public List<MovieModel> getMovieGenre(String genre){
		List<MovieModel> modellist = this.movieRepository.findAllByMoviegenre(genre);
		return modellist;
	}
	
	//get movies by year
	public List<MovieModel> getMovieYear(int year){
		List<MovieModel> modellist = this.movieRepository.findAllByMoviereleaseyear(year);
		return modellist;
	}
	
	
	//	create movie
	@Transactional
	public void addMovie(MovieModel model) {
		this.movieRepository.save(model);
	}
	
	// update movie
	@Transactional
	public void updateMovie(int movieid, MovieModel newmodel) {
		newmodel.setMovieid(movieid);
		this.movieRepository.save(newmodel);
	}
	
	// delete movie
	@Transactional
	public void deleteMovie(int movieid) {
		this.movieRepository.deleteById(movieid);
	}
	
	
	
}
