package com.cts.eventsys.model;




import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
//import javax.persistence.Table;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class Events {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int eventId;
	
	private String eventName;
	private String eventAddress;
	private String eventCity;
	private String eventDescription;
	private String eventImagePath;
	private int eventPrice;
	private String eventDate;
	private String eventTime;
	
	
	
	
	
	

}
