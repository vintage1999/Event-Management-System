package com.cts.movie.movie.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Entity
@IdClass(BookerIdModel.class)
public class BookingModel {
	@Id
	private int userid;
	
	@Id
	private int movieid;

	public BookingModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingModel(int userid, int movieid) {
		super();
		this.userid = userid;
		this.movieid = movieid;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public int getMovieid() {
		return movieid;
	}

	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}

	@Override
	public String toString() {
		return "BookingModel [userid=" + userid + ", movieid=" + movieid + "]";
	}
	
	
}
