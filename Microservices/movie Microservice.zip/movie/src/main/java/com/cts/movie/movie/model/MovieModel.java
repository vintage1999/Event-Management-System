package com.cts.movie.movie.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="movie")
public class MovieModel {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int movieid;
    
    private String moviename;
    private String moviedescription;
    private String moviegenre;
    private String movievideopath;
    private double movieprice;
    private int moviereleaseday;
    private int moviereleasemonth;
    private int moviereleaseyear;

    public MovieModel() {
        super();
    }

	public MovieModel(int movieid, String moviename, String moviedescription, String moviegenre, String movievideopath,
			double movieprice, int moviereleaseday, int moviereleasemonth, int moviereleaseyear) {
		super();
		this.movieid = movieid;
		this.moviename = moviename;
		this.moviedescription = moviedescription;
		this.moviegenre = moviegenre;
		this.movievideopath = movievideopath;
		this.movieprice = movieprice;
		this.moviereleaseday = moviereleaseday;
		this.moviereleasemonth = moviereleasemonth;
		this.moviereleaseyear = moviereleaseyear;
	}

	public int getMovieid() {
		return movieid;
	}

	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}

	public String getMoviename() {
		return moviename;
	}

	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}

	public String getMoviedescription() {
		return moviedescription;
	}

	public void setMoviedescription(String moviedescription) {
		this.moviedescription = moviedescription;
	}

	public String getMoviegenre() {
		return moviegenre;
	}

	public void setMoviegenre(String moviegenre) {
		this.moviegenre = moviegenre;
	}

	public String getMovievideopath() {
		return movievideopath;
	}

	public void setMovievideopath(String movievideopath) {
		this.movievideopath = movievideopath;
	}

	public double getMovieprice() {
		return movieprice;
	}

	public void setMovieprice(double movieprice) {
		this.movieprice = movieprice;
	}

	public int getMoviereleaseday() {
		return moviereleaseday;
	}

	public void setMoviereleaseday(int moviereleaseday) {
		this.moviereleaseday = moviereleaseday;
	}

	public int getMoviereleasemonth() {
		return moviereleasemonth;
	}

	public void setMoviereleasemonth(int moviereleasemonth) {
		this.moviereleasemonth = moviereleasemonth;
	}

	public int getMoviereleaseyear() {
		return moviereleaseyear;
	}

	public void setMoviereleaseyear(int moviereleaseyear) {
		this.moviereleaseyear = moviereleaseyear;
	}

	@Override
	public String toString() {
		return "MovieModel [movieid=" + movieid + ", moviename=" + moviename + ", moviedescription=" + moviedescription
				+ ", moviegenre=" + moviegenre + ", movievideopath=" + movievideopath + ", movieprice=" + movieprice
				+ ", moviereleaseday=" + moviereleaseday + ", moviereleasemonth=" + moviereleasemonth
				+ ", moviereleaseyear=" + moviereleaseyear + "]";
	}
    
}