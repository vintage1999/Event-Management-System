package com.cts.eventsys.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.eventsys.model.Events;
import com.cts.eventsys.repo.EventRepo;
import com.cts.eventsys.service.EventManagemetService;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@CrossOrigin
@RestController
public class EventController {
	@Autowired
	EventRepo repo;
	@Autowired
	private EventManagemetService ems;
	
	
	
	@PostMapping("/addEvents")
	public String addEvents(@RequestBody Events events)
	{
		ems.addEvents(events);
		return "Added Succesfully";
		
	}
	
		
	@GetMapping("/displayEvents")
	public ResponseEntity<HashMap<String, Object>> displayEvents() {
        List<Events> evenList = ems.display();
	
	     HashMap<String,Object> response = new HashMap<>();
	     response.put("Events",evenList);
	      return new ResponseEntity<>(response,HttpStatus.OK);
	}
	 @GetMapping("/citys/{eventCity}")
	 public List<Events> getEventsByCity(@PathVariable String eventCity)
	 {
		 List<Events> ev =  this.repo.findAllByEventCity(eventCity);
		 return ev;
	 }
	 @GetMapping("/events/{id}")
	 public Events getEventsByCity(@PathVariable int id)
	 {
		 Optional<Events> ev =  this.repo.findById(id);
		 return ev.get();
	 }
	 @PutMapping("/events/{id}")
	 public void updateEvents(@RequestBody Events event,@PathVariable int id)
	 {
		 this.ems.updateEvent(id, event);
		 
	 }
	 
	 @DeleteMapping("deleteevent/{id}")
	 public void deleteEvents(@PathVariable int id)
	 {
		 this.ems.deleteEvents(id);
		 
		 
	 }
	 @GetMapping("/date/{eventDate}")
	 @ResponseBody
	 public List<Events> getEventByDate(@PathVariable String eventDate)
	 {
		 List<Events> gt = repo.findAllByEventDate( eventDate);
		 return gt;
	 }
	 
	
//	@GetMapping("/location/{eventCity}")
//	 public Events listAll(@PathVariable String eventCity) {
//		return repo.findByLocation(eventCity);
       
	}

    
	


