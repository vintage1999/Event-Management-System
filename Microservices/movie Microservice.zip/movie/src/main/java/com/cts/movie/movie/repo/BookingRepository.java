package com.cts.movie.movie.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.movie.movie.model.BookerIdModel;
import com.cts.movie.movie.model.BookingModel;

import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<BookingModel, BookerIdModel> {

	@Query(value = "SELECT * FROM BOOKING_MODEL b WHERE b.userid = ?1",nativeQuery = true)
	List<BookingModel> findEventsByUser(int userid);
	
}
