package com.cts.eventsys.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestBody;

import com.cts.eventsys.model.Events;
import com.cts.eventsys.repo.EventRepo;



@Service
public class EventManagementServiceImpl implements EventManagemetService {

	@Autowired
	private EventRepo  repo;

	
	
	@Override
   public Events addEvents(Events event) {
		
		Events savedEvent=this.repo.save(event);

		// TODO Auto-generated method stub
		return savedEvent;
	}
	@Override
	public List<Events> display() {
		// TODO Auto-generated method stub
		return this.repo.findAll();
	}
	@Override
	public void updateEvent(int eventid, Events event) {
		// TODO Auto-generated method stub
		this.repo.save(event);
		
		
	}
	@Override
	public void deleteEvents(int eventid) {
		this.repo.deleteById(eventid);

		
	}
	
//	public void updateEvents(int eventid, Events event) {
//		
	
	
//	@Override
//	public Events findByLocation(String city) {
//		Events op = this.findByLocation(city);
//		return op;
	}

	

//	@Override
//	public Events eventByLocation(  String location) {
//		Events op =  this.repo.eventByLocation(location);
//		System.out.println(op);
//        return op;
//
//		return ;
//	}
	

