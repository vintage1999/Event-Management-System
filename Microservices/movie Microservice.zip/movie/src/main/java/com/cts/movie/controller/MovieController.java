package com.cts.movie.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.movie.movie.model.MovieModel;
import com.cts.movie.movie.service.MovieService;

@RestController
@CrossOrigin
@RequestMapping(value = "/movies")
public class MovieController {

	@Autowired
	private MovieService movieService;

	// get movie by id [For Info]
	@GetMapping(value = "/{movieid}")
	public ResponseEntity<MovieModel> getMovieById(@PathVariable("movieid") int movieid) {
		try {
			MovieModel result = this.movieService.getMovie(movieid);
			return ResponseEntity.of(Optional.of(result));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
	}

	// get all movies [For User]
	@GetMapping(value = "/")
	public ResponseEntity<List<MovieModel>> getMovies() {
		try {
			List<MovieModel> result = this.movieService.getAllMovies();
			return ResponseEntity.of(Optional.of(result));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}

	}

	//get movie list for user by id
	@GetMapping(value = "/user/{id}")
	public ResponseEntity<List<MovieModel>> getUserMovies(@PathVariable("id") int id) {
		try {
			List<MovieModel> result = this.movieService.getUserMovies(id);
			return ResponseEntity.of(Optional.of(result));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}

	}

	// get movie by genre
	@GetMapping(value = "/genre/{genre}")
	public ResponseEntity<List<MovieModel>> getMovieGenre(@PathVariable("genre") String genre) {
		try {
			List<MovieModel> result = this.movieService.getMovieGenre(genre);
			return ResponseEntity.of(Optional.of(result));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}

	}

	// get movie by year
	@GetMapping(value = "/year/{year}")
	public ResponseEntity<List<MovieModel>> getMovieYear(@PathVariable("year") int year) {
		try {
			List<MovieModel> result = this.movieService.getMovieYear(year);
			return ResponseEntity.of(Optional.of(result));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}

	}

	// create movie
	@PostMapping(value = "/")
	public ResponseEntity<MovieModel> addMovie(@RequestBody MovieModel model) {
		try {
			this.movieService.addMovie(model);
//			return ResponseEntity.status(HttpStatus.CREATED).build();
			return new ResponseEntity<MovieModel>(model, HttpStatus.CREATED);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	// update movie
	@PutMapping(value = "/{movieid}")
	public ResponseEntity<MovieModel> updateMovie(@RequestBody MovieModel model, @PathVariable("movieid") int movieid) {
		try {
			MovieModel result = this.movieService.getMovie(movieid);
			if (result == null) {
				throw new NotFoundException();
			}
			this.movieService.updateMovie(movieid, model);
			return new ResponseEntity<MovieModel>(model, HttpStatus.OK);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	// delete movie
	@DeleteMapping(value = "/{movieid}")
	public ResponseEntity<Void> deleteMovie(@PathVariable("movieid") int movieid) {
		try {
			this.movieService.deleteMovie(movieid);
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

}
