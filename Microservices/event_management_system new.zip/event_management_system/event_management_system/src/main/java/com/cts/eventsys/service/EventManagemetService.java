package com.cts.eventsys.service;

import java.util.List;

import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.RequestBody;

import com.cts.eventsys.model.Events;



@Service
public interface EventManagemetService {
	
	public Events addEvents(Events ev);
	public List<Events> display();
	public void updateEvent(int eventid,Events event);
	public void deleteEvents(int eventid);
	
		
	

}
