package com.cts.movie.movie.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.movie.movie.model.MovieModel;

@Repository
public interface MovieRepository extends JpaRepository<MovieModel, Integer>{
	public List<MovieModel> findAllByMoviegenre(String moviegenre);
	public List<MovieModel> findAllByMoviereleaseyear(int year);
	
	@Query(value="select * from movie where movieid in (select movieid from booking_model where userid=?1)",nativeQuery = true)
	public List<MovieModel> findByUserMovieId(int id);
}
